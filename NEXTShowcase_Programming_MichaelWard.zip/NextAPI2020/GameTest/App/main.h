//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
#ifndef _MAIN_H_
#define _MAIN_H_

#include <Windows.h>

extern int WINDOW_WIDTH;
extern int WINDOW_HEIGHT;
extern HWND MAIN_WINDOW_HANDLE;

#endif