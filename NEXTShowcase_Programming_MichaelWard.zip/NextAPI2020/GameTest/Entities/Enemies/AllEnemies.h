#ifndef ALL_ENEMIES_H
#define ALL_ENEMIES_H

// Oops all enemies
#include "Spike.h"

#endif