#ifndef ALL_LEVELS_H
#define ALL_LEVELS_H

// Oops all levels
#include "CircleLevel.h"
#include "SquareLevel.h"
#include "CrossLevel.h"
#include "TriangleLevel.h"
#endif
